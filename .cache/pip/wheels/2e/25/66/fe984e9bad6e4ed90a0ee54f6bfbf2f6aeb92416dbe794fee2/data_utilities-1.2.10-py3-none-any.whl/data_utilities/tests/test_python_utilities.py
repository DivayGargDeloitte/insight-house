"""Test python_utilities from this module."""

from data_utilities.tests.test_support import (
    TestDataUtilitiesTestCase, TestMetaClass)

from data_utilities import python_utilities as pyu


# TODO: implement this test case.
class TestPythonUtilities(TestDataUtilitiesTestCase, metaclass=TestMetaClass):
    """Test class for python_utilities."""

    pyu
    pass
