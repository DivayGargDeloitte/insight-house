from utilitiespackage.cli import main

main()
